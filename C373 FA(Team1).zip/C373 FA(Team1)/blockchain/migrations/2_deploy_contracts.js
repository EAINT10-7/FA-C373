const TicketNFT = artifacts.require("TicketNFT");
const LoyaltyToken = artifacts.require("LoyaltyToken");
const PaymentEscrow = artifacts.require("PaymentEscrow");
const FractionalNFT = artifacts.require("FractionalNFT");

module.exports = async function (deployer) {
  await deployer.deploy(TicketNFT);
  await deployer.deploy(LoyaltyToken);
  await deployer.deploy(PaymentEscrow);
  await deployer.deploy(FractionalNFT);
};
