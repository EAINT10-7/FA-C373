import { Router } from "express";
import {
  organizerMiddleware,
  renderLogin,
  handleLogin,
  handleLogout,
  dashboard,
  newEventForm,
  createEvent,
  addTicketType
} from "../controllers/organizerController.js";

const router = Router();

router.get("/login", renderLogin);
router.post("/login", handleLogin);
router.post("/logout", handleLogout);

router.get("/", organizerMiddleware, dashboard);
router.get("/events/new", organizerMiddleware, newEventForm);
router.post("/events", organizerMiddleware, createEvent);
router.post("/events/:id/types", organizerMiddleware, addTicketType);

export default router;
