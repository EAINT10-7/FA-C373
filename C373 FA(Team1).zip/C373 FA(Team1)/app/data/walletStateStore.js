import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const WALLET_STATE_PATH = path.join(__dirname, "walletState.json");
const walletState = new Map();
const DEFAULT_REWARD_PER_PURCHASE = 10;

function loadWalletStateFromDisk() {
  try {
    if (!fs.existsSync(WALLET_STATE_PATH)) return;
    const raw = fs.readFileSync(WALLET_STATE_PATH, "utf-8");
    const data = JSON.parse(raw);
    if (!data || typeof data !== "object") return;
    Object.entries(data).forEach(([wallet, state]) => {
      if (!wallet || !state) return;
      walletState.set(wallet, {
        tickets: Array.isArray(state.tickets) ? state.tickets : [],
        transactions: Array.isArray(state.transactions) ? state.transactions : [],
        reward: Number.isFinite(Number(state.reward)) ? Number(state.reward) : 0
      });
    });
  } catch {
    // Ignore load errors and start fresh
  }
}

function saveWalletStateToDisk() {
  try {
    const obj = {};
    walletState.forEach((state, wallet) => {
      obj[wallet] = state;
    });
    fs.writeFileSync(WALLET_STATE_PATH, JSON.stringify(obj, null, 2), "utf-8");
  } catch {
    // Ignore save errors in prototype mode
  }
}

loadWalletStateFromDisk();

export function normalizeWalletAddress(wallet) {
  if (typeof wallet !== "string") return null;
  const trimmed = wallet.trim();
  return trimmed ? trimmed.toLowerCase() : null;
}

export function getWalletAddressFromReq(req) {
  return normalizeWalletAddress(
    req.body?.wallet || req.query?.wallet || req.cookies?.ticketnft_wallet
  );
}

export function ensureWalletStateObj(wallet) {
  if (!wallet) return null;
  if (!walletState.has(wallet)) {
    walletState.set(wallet, { tickets: [], transactions: [], reward: 0 });
    saveWalletStateToDisk();
  }
  return walletState.get(wallet);
}

export function setWalletCookieRes(res, wallet) {
  if (!wallet) return;
  res.cookie("ticketnft_wallet", wallet, { httpOnly: true, sameSite: "lax" });
}

export function getRewardPerPurchase() {
  return DEFAULT_REWARD_PER_PURCHASE;
}

export function saveWalletStateObj(wallet) {
  if (!wallet) return;
  if (!walletState.has(wallet)) return;
  saveWalletStateToDisk();
}
