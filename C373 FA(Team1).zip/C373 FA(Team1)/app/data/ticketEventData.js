// Event data store (based on events.json)
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const EVENTS_PATH = path.join(__dirname, "ticketEvents.json");

export function loadTicketEvents() {
  if (!fs.existsSync(EVENTS_PATH)) return [];
  return JSON.parse(fs.readFileSync(EVENTS_PATH, "utf-8"));
}

export function saveTicketEvents(events) {
  fs.writeFileSync(EVENTS_PATH, JSON.stringify(events, null, 2), "utf-8");
}
