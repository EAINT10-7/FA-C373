// Wallet state data (based on state.json)
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const WALLET_STATE_DATA_PATH = path.join(__dirname, "walletStateData.json");

export function loadWalletStateData() {
  if (!fs.existsSync(WALLET_STATE_DATA_PATH)) return {};
  return JSON.parse(fs.readFileSync(WALLET_STATE_DATA_PATH, "utf-8"));
}

export function saveWalletStateData(data) {
  fs.writeFileSync(WALLET_STATE_DATA_PATH, JSON.stringify(data, null, 2), "utf-8");
}
