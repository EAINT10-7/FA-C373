// Controller for wallet and ticket API endpoints
import {
  ensureWalletState,
  getTokPerPurchase,
  getWalletFromReq,
  normalizeWallet,
  saveWalletState,
  setWalletCookie
} from "../data/stateStore.js";

function toNumber(value) {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function uniqueTokenId(state) {
  const existing = new Set(state.tickets.map(t => t.tokenId).filter(Number.isFinite));
  let tokenId = Date.now() % 1000000000;
  while (existing.has(tokenId)) {
    tokenId = (tokenId + Math.floor(Math.random() * 1000) + 1) % 1000000000;
  }
  return tokenId;
}

export function connectWallet(req, res) {
  // ...existing code from connectWallet...
  // ...
}

export function recordPurchase(req, res) {
  // ...existing code from recordPurchase...
  // ...
}

export function redeemReward(req, res) {
  // ...existing code from redeemReward...
  // ...
}

export function getTickets(req, res) {
  // ...existing code from getTickets...
  // ...
}

export function getTransactions(req, res) {
  // ...existing code from getTransactions...
  // ...
}

export function getRewards(req, res) {
  // ...existing code from getRewards...
  // ...
}
