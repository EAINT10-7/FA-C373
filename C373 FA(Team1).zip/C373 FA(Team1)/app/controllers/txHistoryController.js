// Controller for transaction history
export function transactions(req, res) {
  res.render("transactions", { title: "Transaction History" });
}
