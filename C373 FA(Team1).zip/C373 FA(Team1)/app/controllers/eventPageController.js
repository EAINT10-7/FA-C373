// Controller for event pages
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function loadEvents() {
  const p = path.join(__dirname, "..", "data", "events.json");
  return JSON.parse(fs.readFileSync(p, "utf-8"));
}

export function home(req, res) {
  // ...existing code from home...
  // ...
}

export function homeNoConnect(req, res) {
  // ...existing code from homeNoConnect...
  // ...
}

export function eventsList(req, res) {
  // ...existing code from eventsList...
  // ...
}

export function eventDetails(req, res) {
  // ...existing code from eventDetails...
  // ...
}

export function about(req, res) {
  // ...existing code from about...
  // ...
}
