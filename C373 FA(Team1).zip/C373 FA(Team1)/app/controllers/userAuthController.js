// Controller for user authentication
const users = new Map();

export function renderLogin(req, res) {
  res.render("login", { title: "Log In", error: null });
}

export function renderSignup(req, res) {
  res.render("signup", { title: "Sign Up", error: null });
}

export function handleSignup(req, res) {
  // ...existing code from handleSignup...
  // ...
}

export function handleLogin(req, res) {
  // ...existing code from handleLogin...
  // ...
}

export function handleLogout(req, res) {
  // ...existing code from handleLogout...
  // ...
}
