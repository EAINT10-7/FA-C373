// Controller for event organizers (sellers)
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const EVENTS_PATH = path.join(__dirname, "..", "data", "events.json");

const ORGANIZER_USERS = new Map([
  ["organizer@example.com", "password123"]
]);

function loadEvents() {
  const raw = fs.readFileSync(EVENTS_PATH, "utf-8");
  return JSON.parse(raw);
}

function saveEvents(events) {
  fs.writeFileSync(EVENTS_PATH, JSON.stringify(events, null, 2), "utf-8");
}

function requireOrganizer(req, res, next) {
  const authedOrganizer = req.cookies?.organizerUser && ORGANIZER_USERS.has(req.cookies.organizerUser);
  const appUser = req.cookies?.authUserRole === "organizer";
  if (authedOrganizer || appUser) return next();
  return res.redirect("/organizer/login");
}

export function organizerMiddleware(req, res, next) {
  return requireOrganizer(req, res, next);
}

export function renderLogin(req, res) {
  res.render("organizer-login", { title: "Organizer Login", error: null });
}

export function handleLogin(req, res) {
  // ...existing code from handleLogin...
  // ...
}

export function handleLogout(req, res) {
  // ...existing code from handleLogout...
  // ...
}

export function dashboard(req, res) {
  // ...existing code from dashboard...
  // ...
}

export function newEventForm(req, res) {
  // ...existing code from newEventForm...
  // ...
}

export function createEvent(req, res) {
  // ...existing code from createEvent...
  // ...
}

export function addTicketType(req, res) {
  // ...existing code from addTicketType...
  // ...
}
