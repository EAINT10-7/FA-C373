import express from "express";
import path from "path";
import morgan from "morgan";
import cookieParser from "cookie-parser";
import { fileURLToPath } from "url";

import mainRoutes from "./routes/mainRoutes.js";
import eventPageRoutes from "./routes/eventPageRoutes.js";
import ticketingRoutes from "./routes/ticketingRoutes.js";
import loyaltyRewardRoutes from "./routes/loyaltyRewardRoutes.js";
import txHistoryRoutes from "./routes/txHistoryRoutes.js";
import walletApiRoutes from "./routes/walletApiRoutes.js";
import organizerRoutes from "./routes/organizerRoutes.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// View engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middleware
app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Expose auth status to views
app.use((req, res, next) => {
  res.locals.loggedIn = !!req.cookies?.authUser;
  res.locals.authUserRole = req.cookies?.authUserRole || "";
  next();
});

// Static: app assets
app.use("/public", express.static(path.join(__dirname, "public")));

// Static: expose blockchain folder to browser (MetaMask scripts + ABI + addresses)
app.use("/blockchain", express.static(path.join(__dirname, "..", "blockchain")));

// Routes
app.use("/", mainRoutes);
app.use("/events", eventPageRoutes);
app.use("/tickets", ticketingRoutes);
app.use("/rewards", loyaltyRewardRoutes);
app.use("/transactions", txHistoryRoutes);
app.use("/", walletApiRoutes);
app.use("/organizer", organizerRoutes);

// 404
app.use((req, res) => {
  res.status(404).render("404", { title: "Not Found" });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`TicketNFT app running on http://localhost:${PORT}`));
